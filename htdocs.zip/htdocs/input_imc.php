<?php

$a = $_GET["varNome"];

echo "Nome: " . $a;

$b = $_GET["varIdade"];

echo "<br>Idade: " . $b;

?>
<form action="http://localhost/Resultado_IMC.php">



    <input id="idvariavelIdade" type="text" hidden name="varIdade" value=<?php
    echo $_GET["varIdade"];
    ?>>

    <input id="idvariavelNome" type="text" hidden name="varNome" value=<?php
    echo $_GET["varNome"];

    ?>>

    <h3>Peso </h3>

    <input id="idvariavelpeso" type="text" name="varPeso" value=<?php if (isset($_GET["varPeso"])) {
        echo $_GET["varPeso"];
    } ?>>


    <h3> Altura </h3>
    <input id="idvariavelAltura" type="text" name="varAltura" value=<?php if (isset($_GET["varAltura"])) {
        echo $_GET["varAltura"];
    } ?>>

    <input type="submit" value="Submeter dados para servidor">

</form>