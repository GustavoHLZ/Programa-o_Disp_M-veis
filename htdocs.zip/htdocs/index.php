<form action="http://localhost/input_imc.php">

    <h3> Nome </h3>
    <input id="idvariavelNome" type="text" name="varNome" value=<?php if (isset($_GET["varNome"])) {
        echo $_GET["varNome"];
    } ?>>
    <h3> Idade </h3>
    <input id="idvariavelIdade" type="text" name="varIdade" value=<?php if (isset($_GET["varIdade"])) {
        echo $_GET["varIdade"];
    } ?>>
    <input type="submit" value="Submeter dados para servidor">
</form>


<?php
if ((isset($_GET["varNome"])) && (isset($_GET["varIdade"]))) {
    $a = $_GET["varNome"];
    $b = $_GET["varIdade"];
}


?>