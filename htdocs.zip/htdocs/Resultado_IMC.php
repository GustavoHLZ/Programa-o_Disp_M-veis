<?php 
    
    $a=$_GET["varNome"];
  $b=$_GET["varIdade"];
  $c=$_GET["varAltura"];
 $d=$_GET["varPeso"];

    echo "Nome: ".$a;
    echo "<br>Idade: ".$b;
    echo "<br>altura: : ".$c;
    echo "<br>Peso: ".$d;

    echo "<br>IMC: ".($c*$c)/$d;

    ?>