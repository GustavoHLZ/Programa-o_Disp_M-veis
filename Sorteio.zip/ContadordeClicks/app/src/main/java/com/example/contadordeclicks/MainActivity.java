package com.example.contadordeclicks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int i = 0;
    EditText edMin, edMax;
    TextView TVResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edMin = findViewById(R.id.editTextMin);
        edMax = findViewById(R.id.editTextMax);
        TVResult = findViewById(R.id.textView);

    }

    public void randNumber(View v) {
        int max,min;
        min=Integer.parseInt(edMin.getText().toString());
        max=Integer.parseInt(edMax.getText().toString());

        Random r = new Random();
        int resultado = r.nextInt((max-min)+1) + min;
        TVResult.setText(Integer.toString(resultado));


    }

}