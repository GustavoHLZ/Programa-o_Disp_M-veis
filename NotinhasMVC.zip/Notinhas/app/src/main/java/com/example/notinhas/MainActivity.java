package com.example.notinhas;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.example.notinhas.Model.Nota;
import com.example.notinhas.controller.NotaController;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
   // SQLiteDatabase db;
  //  EditText editText;

    NotaController notaController;
    ListView listview;

    ArrayList<Nota> notas;
    ArrayList<String> tituloNotas;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //  editText = findViewById(R.id.editText);
        listview = findViewById(R.id.listView);
        notaController =new NotaController(getApplicationContext());
        fab=findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CadastrarActivity.class);
                startActivity(i);
            }
        });
      atualizaLista();



        //   db = openOrCreateDatabase("minhasnotinhas", MODE_PRIVATE, null);
        // db.execSQL("CREATE TABLE IF NOT EXISTS notas(id INTEGER PRIMARY KEY AUTOINCREMENT,txt VARCHAR);");

        //   findViewById(R.id.btnSalvar).setOnClickListener(new View.OnClickListener() {
        //   @Override
        // public void onClick(View view) {
        //  String texto  = editText.getText().toString();
        //   ContentValues cv = new ContentValues();
        //    cv.put("txt", texto);
        //    db.insert("notas", null, cv);
        //    listaNotas();
        // }
        //  });
        //  listaNotas();
        //}

        //public void listaNotas() {
        //   Cursor cursor = db.rawQuery("SELECT * FROM notas", null);
        // cursor.moveToFirst();
        // ArrayList<String> listatxtnotas = new ArrayList<>();

        // while (!cursor.isAfterLast()) {
        //    listatxtnotas.add(Integer.toString(cursor.getInt(0)) + cursor.getString(1));
        //     Log.d("dbselect", Integer.toString(cursor.getInt(0)) + cursor.getString(1));
        //    cursor.moveToNext();

        ///  }
        //   ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listatxtnotas);
        //   listview.setAdapter(adapter);
        //   }


// }
    }

     public void atualizaLista(){
         notas=notaController.listarNotas();
         tituloNotas=getTituloNotas(notas);

         ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,android.R.id.text1,tituloNotas);
        listview.setAdapter(adapter);
     }

    public ArrayList<String> getTituloNotas(ArrayList<Nota> lnotas) {
        ArrayList<String> result = new ArrayList<>();
        for(Nota nota: lnotas) {
           result.add(nota.getTitulo());
        }
        return result;
    }

}